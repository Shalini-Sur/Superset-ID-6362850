using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Authorize(Roles = "Admin,POC")]
[ServiceFilter(typeof(CustomAuthFilter))]
[ApiController]
[Route("[controller]")]
public class EmployeeController : ControllerBase
{
    private static List<Employee> employees = new List<Employee>
    {
        new Employee
        {
            Id = 1,
            Name = "Shalini",
            Salary = 50000,
            Permanent = true,
            Department = new Department { Id = 1, Name = "IT" },
            Skills = new List<Skill> { new Skill { Id = 1, Name = "C#" } },
            DateOfBirth = new DateTime(2002, 01, 01)
        }
    };

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public ActionResult<IEnumerable<Employee>> Get()
    {
        return Ok(employees);
    }

    [HttpPost]
    public ActionResult<Employee> Post([FromBody] Employee emp)
    {
        employees.Add(emp);
        return Ok(emp);
    }

    [HttpPut("{id}")]
    public ActionResult<Employee> Put(int id, [FromBody] Employee updatedEmp)
    {
        var emp = employees.FirstOrDefault(e => e.Id == id);
        if (id <= 0 || emp == null)
            return BadRequest("Invalid employee id");

        emp.Name = updatedEmp.Name;
        return Ok(emp);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var emp = employees.FirstOrDefault(e => e.Id == id);
        if (emp == null)
            return BadRequest("Invalid employee id");

        employees.Remove(emp);
        return NoContent();
    }
}