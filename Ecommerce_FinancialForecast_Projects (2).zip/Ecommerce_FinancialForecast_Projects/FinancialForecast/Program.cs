using System;

class FinancialForecast
{
    public static double PredictFutureValue(double currentValue, double growthRate, int years)
    {
        if (years == 0)
            return currentValue;
        return PredictFutureValue(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static double PredictFutureValueIterative(double currentValue, double growthRate, int years)
    {
        for (int i = 0; i < years; i++)
        {
            currentValue *= (1 + growthRate);
        }
        return currentValue;
    }

    public static void Main()
    {
        double currentValue = 10000;
        double annualGrowthRate = 0.08;
        int forecastYears = 5;

        Console.WriteLine("--- Recursive Forecast ---");
        Console.WriteLine("Future Value: " + PredictFutureValue(currentValue, annualGrowthRate, forecastYears));

        Console.WriteLine("--- Iterative Forecast ---");
        Console.WriteLine("Future Value: " + PredictFutureValueIterative(currentValue, annualGrowthRate, forecastYears));
    }
}
