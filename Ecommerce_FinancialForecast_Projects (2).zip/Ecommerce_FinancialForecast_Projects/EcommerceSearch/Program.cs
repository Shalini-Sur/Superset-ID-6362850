using System;

class Product
{
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public string Category { get; set; }

    public Product(int id, string name, string category)
    {
        ProductId = id;
        ProductName = name;
        Category = category;
    }
}

class SearchAlgorithms
{
    public static int LinearSearch(Product[] products, string name)
    {
        for (int i = 0; i < products.Length; i++)
        {
            if (products[i].ProductName == name)
                return i;
        }
        return -1;
    }

    public static int BinarySearch(Product[] products, string name)
    {
        int left = 0, right = products.Length - 1;
        while (left <= right)
        {
            int mid = (left + right) / 2;
            int comparison = string.Compare(products[mid].ProductName, name);
            if (comparison == 0)
                return mid;
            else if (comparison < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }

    public static void Main()
    {
        Product[] products = new Product[]
        {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Shoes", "Fashion"),
            new Product(3, "Book", "Education"),
            new Product(4, "Phone", "Electronics")
        };

        Console.WriteLine("--- Linear Search ---");
        int index = LinearSearch(products, "Phone");
        Console.WriteLine(index != -1 ? "Product found at index: " + index : "Product not found");

        Array.Sort(products, (a, b) => a.ProductName.CompareTo(b.ProductName));

        Console.WriteLine("--- Binary Search ---");
        index = BinarySearch(products, "Phone");
        Console.WriteLine(index != -1 ? "Product found at index: " + index : "Product not found");
    }
}
