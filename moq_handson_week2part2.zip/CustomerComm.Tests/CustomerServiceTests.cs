using NUnit.Framework;
using Moq;
using CustomerCommLib;

namespace CustomerComm.Tests
{
    [TestFixture]
    public class CustomerServiceTests
    {
        private Mock<ICustomerRepository> _mockRepo;
        private CustomerService _service;

        [SetUp]
        public void Setup()
        {
            _mockRepo = new Mock<ICustomerRepository>();
            _mockRepo.Setup(r => r.GetCustomerEmail(It.IsAny<int>()))
                     .Returns("mockeduser@example.com");

            _service = new CustomerService(_mockRepo.Object);
        }

        [Test]
        public void FetchCustomerEmail_ShouldReturnMockedEmail()
        {
            var result = _service.FetchCustomerEmail(1);
            Assert.AreEqual("mockeduser@example.com", result);
        }
    }
}