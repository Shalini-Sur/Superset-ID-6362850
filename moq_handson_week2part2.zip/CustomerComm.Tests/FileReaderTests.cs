using NUnit.Framework;
using Moq;
using CustomerCommLib;

namespace CustomerComm.Tests
{
    [TestFixture]
    public class FileReaderTests
    {
        private Mock<IFileSystem> _mockFileSystem;
        private FileReader _fileReader;

        [SetUp]
        public void Setup()
        {
            _mockFileSystem = new Mock<IFileSystem>();
            _mockFileSystem.Setup(fs => fs.ReadFile(It.IsAny<string>()))
                           .Returns("Mock file content");

            _fileReader = new FileReader(_mockFileSystem.Object);
        }

        [Test]
        public void GetContent_ShouldReturnMockContent()
        {
            var content = _fileReader.GetContent("dummy.txt");
            Assert.AreEqual("Mock file content", content);
        }
    }
}