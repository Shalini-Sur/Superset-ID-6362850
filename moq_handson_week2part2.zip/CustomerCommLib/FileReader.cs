namespace CustomerCommLib
{
    public interface IFileSystem
    {
        string ReadFile(string filePath);
    }

    public class FileReader
    {
        private readonly IFileSystem _fileSystem;

        public FileReader(IFileSystem fileSystem)
        {
            _fileSystem = fileSystem;
        }

        public string GetContent(string path)
        {
            return _fileSystem.ReadFile(path);
        }
    }
}