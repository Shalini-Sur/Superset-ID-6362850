namespace CustomerCommLib
{
    public interface ICustomerRepository
    {
        string GetCustomerEmail(int customerId);
    }

    public class CustomerService
    {
        private readonly ICustomerRepository _repository;

        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }

        public string FetchCustomerEmail(int customerId)
        {
            return _repository.GetCustomerEmail(customerId);
        }
    }
}