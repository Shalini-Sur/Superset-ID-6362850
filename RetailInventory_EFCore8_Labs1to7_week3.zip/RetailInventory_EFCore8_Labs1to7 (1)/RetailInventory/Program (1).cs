using System;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using RetailInventory.Models;

class Program
{
    static async Task Main()
    {
        using var context = new AppDbContext();

        // LAB 4: Insert initial data if not already present
        if (!context.Categories.Any())
        {
            var electronics = new Category { Name = "Electronics" };
            var groceries = new Category { Name = "Groceries" };
            await context.Categories.AddRangeAsync(electronics, groceries);

            var product1 = new Product { Name = "Laptop", Price = 75000, Category = electronics };
            var product2 = new Product { Name = "Rice Bag", Price = 1200, Category = groceries };
            await context.Products.AddRangeAsync(product1, product2);

            await context.SaveChangesAsync();
        }

        // LAB 5: Display all products
        var products = await context.Products.Include(p => p.Category).ToListAsync();
        Console.WriteLine("All Products:");
        foreach (var p in products)
            Console.WriteLine($"{p.Name} - ₹{p.Price} ({p.Category?.Name})");

        // LAB 6: Update a product
        var laptop = await context.Products.FirstOrDefaultAsync(p => p.Name == "Laptop");
        if (laptop != null)
        {
            laptop.Price = 70000;
            await context.SaveChangesAsync();
            Console.WriteLine("Laptop price updated.");
        }

        // LAB 6: Delete a product
        var rice = await context.Products.FirstOrDefaultAsync(p => p.Name == "Rice Bag");
        if (rice != null)
        {
            context.Products.Remove(rice);
            await context.SaveChangesAsync();
            Console.WriteLine("Rice Bag deleted.");
        }

        // LAB 7: LINQ query - expensive products
        var expensive = await context.Products
            .Where(p => p.Price > 50000)
            .OrderByDescending(p => p.Price)
            .ToListAsync();

        Console.WriteLine("Expensive Products:");
        foreach (var item in expensive)
            Console.WriteLine($"{item.Name} - ₹{item.Price}");
    }
}
