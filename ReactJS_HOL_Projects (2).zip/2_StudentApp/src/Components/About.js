import React from 'react';

function About() {
  return <h2>Welcome to the About page of the Student Management Portal</h2>;
}

export default About;
