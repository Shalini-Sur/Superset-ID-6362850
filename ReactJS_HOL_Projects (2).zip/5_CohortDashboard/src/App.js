import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  return (
    <div>
      <CohortDetails name="React Basics" status="Ongoing" startDate="2025-07-01" endDate="2025-08-01" />
      <CohortDetails name="JavaScript Advanced" status="Completed" startDate="2025-06-01" endDate="2025-07-01" />
    </div>
  );
}

export default App;
