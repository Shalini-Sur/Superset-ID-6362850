using System;

namespace UtilLib
{
    public class UrlHostNameParser
    {
        public string ParseHostName(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                return "Invalid URL";

            try
            {
                var uri = new Uri(url);
                return uri.Host;
            }
            catch
            {
                return "Invalid URL";
            }
        }
    }
}