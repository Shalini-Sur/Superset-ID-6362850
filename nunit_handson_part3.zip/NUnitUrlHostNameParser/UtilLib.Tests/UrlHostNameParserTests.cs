using NUnit.Framework;
using UtilLib;

namespace UtilLib.Tests
{
    [TestFixture]
    public class UrlHostNameParserTests
    {
        private UrlHostNameParser _parser;

        [SetUp]
        public void Setup()
        {
            _parser = new UrlHostNameParser();
        }

        [Test]
        public void ParseHostName_ValidUrl_ReturnsHost()
        {
            string url = "https://www.example.com/page";
            string result = _parser.ParseHostName(url);
            Assert.That(result, Is.EqualTo("www.example.com"));
        }

        [Test]
        public void ParseHostName_InvalidUrl_ReturnsInvalid()
        {
            string url = "not_a_valid_url";
            string result = _parser.ParseHostName(url);
            Assert.That(result, Is.EqualTo("Invalid URL"));
        }

        [Test]
        public void ParseHostName_EmptyUrl_ReturnsInvalid()
        {
            string url = "";
            string result = _parser.ParseHostName(url);
            Assert.That(result, Is.EqualTo("Invalid URL"));
        }
    }
}