public interface IDocument
{
    void Open();
}
