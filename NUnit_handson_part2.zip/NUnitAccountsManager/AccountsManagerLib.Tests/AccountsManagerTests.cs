using NUnit.Framework;
using AccountsManagerLib;
using System;

namespace AccountsManagerLib.Tests
{
    [TestFixture]
    public class AccountsManagerTests
    {
        private AccountsManager _manager;

        [SetUp]
        public void Setup()
        {
            _manager = new AccountsManager();
        }

        [Test]
        public void Login_ValidCredentials_ReturnsWelcomeMessage()
        {
            string result = _manager.Login("user_11", "secret@user11");
            Assert.That(result, Is.EqualTo("Welcome user_11!!!"));
        }

        [Test]
        public void Login_InvalidCredentials_ReturnsInvalidMessage()
        {
            string result = _manager.Login("wrong_user", "wrong_pass");
            Assert.That(result, Is.EqualTo("Invalid user id/password"));
        }

        [Test]
        public void Login_MissingUserId_ThrowsArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() => _manager.Login("", "somepassword"));
            Assert.That(ex.Message, Is.EqualTo("User ID and Password cannot be empty"));
        }

        [Test]
        public void Login_MissingPassword_ThrowsArgumentException()
        {
            var ex = Assert.Throws<ArgumentException>(() => _manager.Login("user_11", ""));
            Assert.That(ex.Message, Is.EqualTo("User ID and Password cannot be empty"));
        }
    }
}