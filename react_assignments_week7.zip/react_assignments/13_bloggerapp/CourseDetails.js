import React from "react";
export default function CourseDetails() {
  return <div>Course Details Component</div>;
}
