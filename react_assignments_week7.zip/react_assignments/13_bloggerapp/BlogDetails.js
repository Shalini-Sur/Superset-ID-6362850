import React from "react";
export default function BlogDetails() {
  return <div>Blog Details Component</div>;
}
