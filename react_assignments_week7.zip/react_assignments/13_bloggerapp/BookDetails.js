import React from "react";
export default function BookDetails() {
  return <div>Book Details Component</div>;
}
