import React from "react";
import "./App.css";

function App() {
  const offices = [
    { name: "Space A", rent: 55000, address: "Bangalore" },
    { name: "Space B", rent: 75000, address: "Hyderabad" }
  ];

  return (
    <div>
      <h1>Office Spaces</h1>
      <div>
        {offices.map((office, index) => (
          <div key={index}>
            <h2>{office.name}</h2>
            <p style={{ color: office.rent > 60000 ? "green" : "red" }}>
              Rent: {office.rent}
            </p>
            <p>Address: {office.address}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
