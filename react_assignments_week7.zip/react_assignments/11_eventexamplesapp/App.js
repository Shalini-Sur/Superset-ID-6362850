import React, { useState } from "react";

function App() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(prev => prev + 1);
    sayHello();
  };

  const sayHello = () => {
    console.log("Hello! This is a static message.");
  };

  const sayWelcome = (msg) => {
    alert(msg);
  };

  const handlePress = () => {
    alert("I was clicked");
  };

  const handleSubmit = () => {
    const rupees = 100;
    const euro = rupees * 0.011;
    alert(`${rupees} INR = ${euro.toFixed(2)} EUR`);
  };

  return (
    <div>
      <h1>Event Examples</h1>
      <p>Counter: {count}</p>
      <button onClick={increment}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
      <button onClick={() => sayWelcome("Welcome!")}>Say Welcome</button>
      <button onClick={handlePress}>OnPress</button>
      <button onClick={handleSubmit}>Convert Rupees to Euro</button>
    </div>
  );
}

export default App;
