import React from "react";

function IndianPlayers() {
  const T20players = ["Rohit", "Kohli"];
  const RanjiTrophy = ["Pujara", "Rahane"];
  const allPlayers = [...T20players, ...RanjiTrophy];

  return (
    <div>
      <h2>All Players</h2>
      <ul>
        {allPlayers.map((name, index) => (
          <li key={index}>{name}</li>
        ))}
      </ul>
    </div>
  );
}

export default IndianPlayers;
