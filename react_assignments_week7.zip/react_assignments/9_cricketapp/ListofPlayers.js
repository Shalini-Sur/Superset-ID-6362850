import React from "react";

function ListofPlayers() {
  const players = [
    { name: "Player 1", score: 80 },
    { name: "Player 2", score: 65 },
    { name: "Player 3", score: 90 },
    { name: "Player 4", score: 55 }
  ];

  const highScorers = players.filter(p => p.score >= 70);

  return (
    <div>
      <h2>High Scoring Players</h2>
      <ul>
        {highScorers.map((player, index) => (
          <li key={index}>{player.name} - {player.score}</li>
        ))}
      </ul>
    </div>
  );
}

export default ListofPlayers;
