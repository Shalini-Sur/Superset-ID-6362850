import React from "react";

function UserPage() {
  return <p>Welcome User! You can now book your tickets.</p>;
}

export default UserPage;
