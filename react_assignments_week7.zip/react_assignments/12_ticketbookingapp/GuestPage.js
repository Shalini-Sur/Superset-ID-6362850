import React from "react";

function GuestPage() {
  return <p>Welcome Guest! Browse available flights.</p>;
}

export default GuestPage;
